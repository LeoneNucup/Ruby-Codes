require_relative "Menu.rb"

class Borrow
  define_method :borrow_menu do
    _menu = Menu.new

    puts ""
    puts "BORROW MENU"
    puts "[1] Show Borrowed Books List"
    puts "[2] Add a Borrowed book"
    puts "[3] Return dates of Books Borrowed"
    puts "[4] Back to Main Menu"
    print "Choice: "
    borrow_choice = gets.chomp

    if borrow_choice == '1'
      borrow_list
      borrow_menu
    elsif borrow_choice == '2'
      check_add_borrowed
      borrow_menu
    elsif borrow_choice == '3'
      check_return_dates
      borrow_menu
    elsif borrow_choice == '4'
      _menu.menu
    else
      borrow_menu
    end

  end

  define_method :borrow_list do
    puts ""
    puts "Borrow List:"
    puts Dir.entries("./Records/Borrow")
    puts ""
  end


  define_method :check_return_dates do
    begin
      print "Name of Borrowed book: "
      checking = gets.chomp

      check_book = File.new("./Records/Borrow/"+checking+".txt", "r")
      puts "Record exists"
      puts check_book.read

      check_book.close()
      rescue
        puts "File NOT found."
    end
  end


  define_method :check_add_borrowed do
    print "Name of the book borrowed: "
    borrowing = gets.chomp
    begin
      bookOpen = File.new("./Records/Books/"+borrowing+".txt", "r")
      puts bookOpen.read
      bookOpen.close()


      add_book = File.new("./Records/Borrow/"+borrowing+".txt", "w+")
      puts "Record exists"
      print "Date when to return: "
      return_date = gets.chomp

      add_book.syswrite("Date of return: " + return_date)
      add_book.close()
      rescue
        puts "File NOT found."
    end
  end
end
