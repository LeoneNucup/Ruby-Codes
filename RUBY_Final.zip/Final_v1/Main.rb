require_relative "Menu.rb"

class Main
  def main
    _menu = Menu.new
    _menu.menu
  end
end


#MAIN#
mainMenu = Main.new
mainMenu.main
