require_relative "Menu.rb"


class Records
  book_title = ""
  book_author = ""
  book_publisher = ""
  book_date = ""

  default_record = Hash["Title" => book_title,
                        "Author" => book_author,
                        "Publisher" => book_publisher,
                        "Date of Publication" => book_date,
                      ]

#-------------------------------ADD-------------------------------------------------------
    define_method :add_record do
      print "Book Title: "
      default_record["Title"] = gets.chomp

      print "\nBook Author: "
      default_record["Author"] = gets.chomp

      print "\nBook's Publisher: "
      default_record["Publisher"] = gets.chomp

      print "\nBook's Date of Publication: "
      default_record["Date of Publication"] = gets.chomp

      puts "Record Saved\n"

      add_record_area

      #Saves the record in another folder
      book_record = File.new("./Records/Books/"+default_record["Title"]+".txt", "w+");
      book_record.syswrite("Title: " + default_record["Title"])
      book_record.syswrite("\nAuthor: " + default_record["Author"])
      book_record.syswrite("\nPublisher: " + default_record["Publisher"])
      book_record.syswrite("\nDate: " + default_record["Date of Publication"])
      book_record.close()
    end

#----------------------------------ADD_AREA--------------------------------------------------

    define_method :add_record_area do
      puts "Area to put the Book"
      puts "[1] A1"
      puts "[2] B1"
      puts "[3] C1"
      print "Choice: "
      area_choice = gets.chomp

      if area_choice == '1'
        read_area("A1")

      elsif area_choice == '2'
        read_area("B1")

      elsif area_choice == '3'
        read_area("C1")

      else
        add_record_area
      end

    end

    def read_area(area)
      area_record = File.new("./Records/Areas/"+ area + ".txt", "r")
      area_count = area_record.read()
      area_count = area_count.to_i
      area_count = area_count + 1
      area_count.to_s
      area_record.close()

      File.delete("./Records/Areas/"+ area + ".txt")

      area_record_2 = File.new("./Records/Areas/"+ area + ".txt", "w+")
      area_record_2.syswrite(area_count)
      area_record_2.close()
    end


    define_method :check_area do
      puts "\nCheck Area.."
      puts "[1] A1"
      puts "[2] B1"
      puts "[3] C1"
      puts "[4] Total Number of books"
      print "Choice: "

      area_check_choice = gets.chomp

      if area_check_choice == '1'
        read_check_area("A1")

      elsif area_check_choice == '2'
        read_check_area("B1")

      elsif area_check_choice == '3'
        read_check_area("C1")

      elsif area_check_choice == '4'
        area_check_A1 = File.new("./Records/Areas/A1.txt", "r")
        area_check_B1 = File.new("./Records/Areas/B1.txt", "r")
        area_check_C1 = File.new("./Records/Areas/C1.txt", "r")

        a1_area_count = area_check_A1.read()
        a1_area_count = a1_area_count.to_i
        b1_area_count = area_check_B1.read()
        b1_area_count = b1_area_count.to_i
        c1_area_count = area_check_C1.read()
        c1_area_count = c1_area_count.to_i

        total_area_count = a1_area_count + b1_area_count + c1_area_count

        puts "Total Book/s: " + total_area_count.to_s

        area_check_A1.close()
        area_check_B1.close()
        area_check_C1.close()
      else
        check_area
      end
    end

    def read_check_area(area)
      area_check = File.new("./Records/Areas/" + area + ".txt", "r")
      puts "\n " + area + ": "
      puts area_check.read + " book/s"
      area_check.close()
    end

#----------------------------------DELETE----------------------------------------------------
    define_method :del_record do
      _Menu = Menu.new

      puts "[1] Delete a Record/ Book"
      puts "[2] Back to Main Menu"
      print "Choice: "
      del_choice = gets.chomp


      if del_choice == '1'
        puts ''
        print "Input name of title of the book: "
        title_to_del = gets.chomp

        begin
          File.delete("./Records/Books/"+title_to_del+".txt")
          rescue
            puts "Try Again"
            del_record
        end

        puts "Succesfully deleted the file"
        puts ""

      elsif del_choice == '2'
        _Menu.menu
      else
        del_record
      end
    end

#----------------------------------EDIT----------------------------------------------------
    define_method :edit_record do
      _Menu = Menu.new

      puts Dir.entries("./Records/Books/")

      print "\nTitle of Book(Case Sensitive) : "
      name = gets.chomp

      if default_record.has_key?(name)
        print "What do you want to edit, Title? Author? Date of Publication? "
        char = gets.chomp
        if default_record[name].has_key?(char)
          print "\n","Change ", char, " into? "
          newval = gets.chomp
          book_record = File.new("./Records/Books/"+name+".txt", "w+");
          default_record[name][char]=newval
          default_record.each do |key,value|
            if key == name
              book_record.syswrite(key)
              value.each do |key,value|
                book_record.syswrite( "\n"+key + " : "+ value)
              end
          end
          end
        end
      book_record.close

      elsif default_record.has_key?(name) == false
        begin
          File.delete("./Records/Books/"+name+".txt")
          add_record
          rescue
            puts "Try Again"
            edit_record
        end

      else
        puts "Book not Found"
      end

    end

end

#-------------------------------GIVING AWAY/ REPAIR--------------------------------------
define_method :away_repair_menu do
  _menu = Menu.new

  puts ""
  puts "Giving Away/ Repair MENU"
  puts "[1] Show Giving Away List"
  puts "[2] Show Repair List"
  puts "[3] Add a Book for Repair"
  puts "[4] Add a Book for Giving Away"
  puts "[5] Back to Main Menu"
  print "Choice: "
  awayrepair_choice = gets.chomp

  if awayrepair_choice == '1'
    away_list
    away_repair_menu
  elsif awayrepair_choice == '2'
    repair_list
    away_repair_menu
  elsif awayrepair_choice == '3'
    check_repair
    away_repair_menu
  elsif awayrepair_choice == '4'
    check_away
    away_repair_menu
  elsif awayrepair_choice == '5'
    _menu.menu
  else
    away_repair_menu
  end

end

define_method :away_list do
  puts ""
  puts "Away List:"
  puts Dir.entries("./Records/Away")
  puts ""
end

define_method :repair_list do
  puts ""
  puts "Repair List:"
  puts Dir.entries("./Records/Repair")
  puts ""
end

define_method :check_away do
  print "Name of the book to be given away: "
  away_book = gets.chomp
  open_book_away(away_book)
end

define_method :check_repair do
  print "Name of the book to be repaired: "
  repair_book = gets.chomp
  open_book(repair_book)
end

def open_book(book)
  begin
    bookOpen = File.new("./Records/Books/"+book+".txt", "r")
    puts bookOpen.read
    bookOpen.close()


    add_book = File.new("./Records/Repair/"+book+".txt", "w+")
    puts "Record exists"
    add_book.syswrite("To be given away")
    add_book.close()
    rescue
      puts "File NOT found."
  end
end

def open_book_away(book)
  begin
    bookOpen = File.new("./Records/Books/"+book+".txt", "r")
    puts bookOpen.read
    bookOpen.close()


    add_book = File.new("./Records/Away/"+book+".txt", "w+")
    puts "Record exists"
    add_book.syswrite("To be given away")
    add_book.close()
    rescue
      puts "File NOT found."
  end
end
