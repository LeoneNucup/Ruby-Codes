require_relative "Records.rb"
require_relative "Borrow.rb"

class Menu
  def menu
    _record = Records.new
    _borrow = Borrow.new

    GC.start
    puts ""
    puts "MAIN MENU"
    puts "[1] ADD RECORDS"
    puts "[2] EDIT RECORDS"
    puts "[3] DELETE RECORDS"
    puts "[4] BORROWED LIST"
    puts "[5] CHECK AREA COUNT"
    puts "[6] GIVING AWAY/ REPAIRS"
    puts "[7] EXIT"

    print "\nChoice: "

    #Please add exception handling
    menuChoice = gets.chomp

    if menuChoice == '1'
      puts ""
      _record.add_record
      menu
    elsif menuChoice == '2'
      puts ""
      _record.edit_record
      menu
    elsif menuChoice == '3'
      puts ""
      _record.del_record
      menu
    elsif menuChoice == '4'
      puts ""
      _borrow.borrow_menu
      menu
    elsif menuChoice == '5'
      _record.check_area
      menu
    elsif menuChoice == '6'
      _record.away_repair_menu
      menu
    elsif menuChoice == '7'
      puts "Closing Program"
      exit(0)
    else
      menu
    end

  end
end
