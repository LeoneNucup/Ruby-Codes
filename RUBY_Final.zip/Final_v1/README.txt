RUBY DNI GROUP
CS-201
Project Team Members
Klarence Nicolas Catalan
Leone Nucup
Kaysie Cruz
Ed Joshua Silva


#To start the app#
Run the "Main.rb" file to initiate the application.
